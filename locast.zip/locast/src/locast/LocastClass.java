package locast;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

public class LocastClass {
	public static String driverPath = "C:/Users/Kavitha/Downloads/chromedriver_win32/";
	public static WebDriver driver;
	
	public static void main(String args[]) {
	
	System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	driver.get("http://locast.org");
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//a[@href ='#login']")).click();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//input[@id='login-username']")).click();
	driver.findElement(By.xpath("//input[@id='login-username']")).sendKeys("name@gmail.com");
	driver.findElement(By.xpath("//input[@id='login-password']")).click();
	driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys("password");
	driver.findElement(By.xpath("//button[@type='submit']")).click();
//	driver.findElement(By.xpath("//a[@class='btn btn-warning']")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//	
	String title=driver.getTitle();
	System.out.println(title);
	//if(driver.getTitle().contains("Market "))
	    //Pass
	  //  System.out.println("Page title contains \"some expected text\" ");
	//else
	    //Fail
	  //  System.out.println("Page title doesn' contains \"some expected text\" ");
	
	
	driver.findElement(By.xpath("//div[@class='channel-logo js-channel active']//img[(@alt='KPIXDT')]")).click();
	driver.findElement(By.xpath("//a[@class='btn btn-warning mt-3']")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	String src_cbs=driver.findElement(By.xpath("//video[@class='video-react-video']")).getAttribute("src");
	
	System.out.println("Video Source of CBS is" + src_cbs);
	
	driver.findElement(By.xpath("//div[@class='channel-logo js-channel active']//img[(@alt='KTVUDT')]")).click();
	driver.findElement(By.xpath("//a[@class='btn btn-warning mt-3']")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	String src_fox=driver.findElement(By.xpath("//video[@class='video-react-video']")).getAttribute("src");
	
	System.out.println("Video Source of CBS is" + src_fox);
	
	driver.findElement(By.xpath("//div[@class='channel-logos']//img[(@alt='KTVUDT')]")).click();
	driver.findElement(By.xpath("//a[@class='btn btn-warning mt-3']")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	String src_nbc=driver.findElement(By.xpath("//video[@class='video-react-video']")).getAttribute("src");
	
	System.out.println("Video Source of CBS is" + src_nbc);
	
	 
	
}
}
